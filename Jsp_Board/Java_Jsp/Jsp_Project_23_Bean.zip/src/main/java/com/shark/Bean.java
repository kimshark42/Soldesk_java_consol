package com.shark;

public class Bean {
	
	private String name;
	private int number;
	
	// 겟터 -> 해당 함수를 가져옴, 국룰은 낙타표기법
	
	//name 변수의 겟터 정의하기
	public String getName() {
		return name;
	}
	//name 변수의 새터 정의하기
	public void setName(String name) {
		this.name = name;
	}
	//number 변수의 게터 정의하기
	public int getNumber() {
		return number;
	}
	//number 변수의 세터 정의하기
	public void setNumber(int number) {
		this.number = number;
	}
}
