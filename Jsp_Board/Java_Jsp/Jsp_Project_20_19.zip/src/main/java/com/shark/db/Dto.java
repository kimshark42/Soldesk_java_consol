package com.shark.db;

public class Dto {
	
	public String category;
	public String no;
	public String title;
	public String id;
	public String datetime;
	public String text;
	public String hit;
	public String replyCount;
	public String replyOri;
	
	public Dto(String category, String no, String title,String id, String text,
			String datetime, String hit, String replyCount, String replyOri) {
		this.category = category;
		this.no = no;
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
		this.hit = hit;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}
	
	public Dto(String category, String title,String id,String text) {
		this.category = category;
		this.title = title;
		this.id = id;
		this.text = text;
	}
	
	public Dto(String title, String text) {
		this.title = title;
		this.text = text;
	}
	
	public String getCategory() {
		return category;
	}
	public String getNo() {
		return no;
	}
	public String getTitle() {
		return title;
	}
	public String getId() {
		return id;
	}
	public String getText() {
		return text;
	}
	public String getDatetime() {
		return datetime;
	}
	public String getHit() {
		return hit;
	}
	public String getReplyCount() {
		return replyCount;
	}
	public String getReplyOri() {
		return replyOri;
	}
}
