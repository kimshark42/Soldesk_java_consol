package com.shark.db;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.shark.board.Board;
import com.shark.util.Sy;

public class Dao extends Da{
	
	/* 로그인 추가 */
	public void reg(String id, String pw) {
		super.connect();
		String sql = String.format("INSERT INTO member values ('%s','%s')", id, pw);
		System.out.println("전송된 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
	
	public String login(String id, String pw) {
		super.connect();
		String sql = String.format("SELECT ID FROM member WHERE ID='%s' AND PW='%s'",id,pw);
		System.out.println("전송된 sql문:"+sql);
		String loginld = null;
		try {
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				loginld = rs.getString("id");
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println("로그인 된 ID:"+loginld);
		super.close();
		
		return loginld;
	}
	
	/* 기존 게시판 기능 */
	
	// 삭제
		public void delete(String category, String no) {
			super.connect();
			// 사실 and 뒤에 오는 sql문은 쓰지 않아도 무방함
			String sql = String.format(
					"DELETE FROM %s WHERE B_NO=%s AND B_CATEGORY LIKE '%s'"
					, Board.TABLE_PS_BOARD, no, category);
			Sy.s("전송한 sql문:" + sql); // 로그
			super.update(sql);
			super.close();
		}

		// 쓰기
		public void write(Dto d) {
			super.connect();
			String sql = String.format("INSRT INTO %s (" 
			+ "B_CATEGORY,B_TITLE,B_ID,B_TEXT,B_DATETIME) VALUES ('%s','%s','%s',now())",
					Board.TABLE_PS_BOARD, d.category, d.title, d.id, d.text);
			Sy.s("전송한 sql문:" + sql); // 로그
			super.update(sql);
			super.close();
		}

		// 글 읽기
		// 여기 하던중, string format  확인 바람
		public Dto read(String category, String no) {
			super.connect();
			Dto post = null;
			try {
				String sql = String.format(
					"SELECT B_CATEGORY,B_NO,B_TITLE,B_ID,B_DATETIME,B_TEXT,B_HIT"
					+",B_REPLY_COUNT,B_REPLY_ORI FROM %s WHERE B_NO=%s AND B_CATEGORY LIKE '%s'"
					, Board.TABLE_PS_BOARD, no, category);
				Sy.s("전송한 sql문:" + sql); // 로그
				ResultSet rs = st.executeQuery(sql);
				rs.next();
				post = new Dto(
						category,
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_TEXT"),
						rs.getString("B_DATETIME"),
						rs.getString("B_HIT"),
						rs.getString("B_REPLY_COUNT"),
						rs.getString("B_REPLY_ORI"));
			} catch (Exception e) {
				e.printStackTrace();
			}
			super.close();
			return post;
		}
		
		// 글 목록
		public ArrayList<Dto> list(String category, int startIndex){
			super.connect();
			ArrayList<Dto> posts = new ArrayList<>();
			try {
				
				String sql = String.format(
						"SELECT * FROM %s WHERE B_CATEGORY LIKE '%s' LIMIT %d,%d"
						,Board.TABLE_PS_BOARD, category, startIndex, Board.LIST_AMOUNT);
				Sy.s("전송한 sql문:"+sql);  // 로그
				ResultSet rs = st.executeQuery(sql);
				while(rs.next()) {
					posts.add(new Dto(
							rs.getString("B_CATEGORY"),
							rs.getString("B_NO"),
							rs.getString("B_TITLE"),
							rs.getString("B_ID"),
							rs.getString("B_TEXT"),
							rs.getString("B_DATETIME"),
							rs.getString("B_HIT"),
							rs.getString("B_REPLY_COUNT"),
							rs.getString("B_REPLY_ORI")
							));
				}
		    } catch(Exception e) {
				e.printStackTrace();
			}
			super.close();
			return posts;
		}
		
		// 총 글 수 구하기
		public int selectPostCount(String category) {
			int count = 0;
			super.connect();
			try {
				String sql = String.format("SELECT CONUT(*) FROM %s WHERE B_CATEGORY LIKE '%s'"
						,Board.TABLE_PS_BOARD, category);
				Sy.s("전송된 sql문:"+sql);  // 로그
				ResultSet rs = st.executeQuery(sql);
				rs.next();
				count = rs.getInt("COUNT(*)");
				} catch(Exception e) {
				    e.printStackTrace();
				}
				super.close();
				return count;
		}
		
		// 글 목록 - 검색모드
		public ArrayList<Dto> selectListSearch(String category, int startIndex, String word){
			super.connect();
			ArrayList<Dto> posts = new ArrayList<>();
			try {			
				String sql = String.format(
						"SELECT B_CATEGORY,B_NO,B_TITLE,B_ID,B_TEXT,B_DATETIME,B_HIT"
						+ "B_REPLY_COUNT,B_REPLY_ORI FROM %s WHERE B_TITLE LIKE '%%%s%%'"
						+ " AND B_CATEGORY LIKE '%s' LIMIT %s,%s"
						,Board.TABLE_PS_BOARD, word, category, startIndex, Board.LIST_AMOUNT);
				Sy.s("전송한 sql문:"+sql);  // 로그
				ResultSet rs = st.executeQuery(sql);
				while(rs.next()) {
					posts.add(new Dto(
							rs.getString("B_CATEGORY"),
							rs.getString("B_NO"),
							rs.getString("B_TITLE"),
							rs.getString("B_ID"),
							rs.getString("B_TEXT"),
							rs.getString("B_DATETIME"),
							rs.getString("B_HIT"),
							rs.getString("B_REPLY_COUNT"),
							rs.getString("B_REPLY_ORI")
							));
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
			super.close();
			return posts;
		}
		
		// 총 글 수 구하기 - 검색모드
		public int selectSearchPostCount(String category, String word) {
			int count = 0;
			super.connect();
			try {
				String sql = String.format("SELECT CONUT(*) FROM %s WHERE B_TITLE LIKE '%%%s%%'"
						+" AND B_CATEGORY LIKE '%s'", Board.TABLE_PS_BOARD, word, category);
				Sy.s("전송된 sql문:"+sql);  // 로그
				ResultSet rs = st.executeQuery(sql);
				rs.next();
				count = rs.getInt("COUNT(*)");
				} catch(Exception e) {
					e.printStackTrace();
				}
				super.close();
				return count;
		}
		
		// 수정
		public void edit(Dto d, String no) {
			super.connect();
			// 작은 따옴표 차단 (2025.05.23 추가적으로 공부해서 헤본것)
			if (d.title.contains("'") || d.text.contains("'")) {
				Sy.s("🚫 작은따옴표가 포함되어 수정이 차단되었습니다.");
				super.close();
				return;  // 더 이상 진행하지 않고 종료
			}		
			String sql = String.format("UPDATE %s SET B_TITLE='%s',B_TEXT='%s' WHERE B_NO=%s"
					,Board.TABLE_PS_BOARD, d.title, d.text, no);
			Sy.s("전송한 sql문:"+sql);  // 로그
			super.update(sql);
			super.close();
		}
}
