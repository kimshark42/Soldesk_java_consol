package com.shark.db;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.shark.util.Sy;

public class Dao extends Da {
	
	// 삭제
	public void delete(String no) {
		super.connect();
		String sql = String.format("DELETE FROM %s WHERE B_NO=%s"
				,Db.TABLE_PS_BOARD_FREE,no);
		Sy.s("전송한 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
	
	// 쓰기
	public void write(Dto d) {
		super.connect();
		String sql = String.format("INSERT INTO %s (B_TITLE, B_ID, B_TEXT) VALUES ("
				+"'%s','%s','%s')",Db.TABLE_PS_BOARD_FREE, d.title, d.id, d.text);
		Sy.s("전송한 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
	
	// 읽기
	public Dto read(String no) {
		super.connect();
		Dto post = null;
		try {
			String sql = String.format("SELECT * FROM %s WHERE B_NO=%s"
					,Db.TABLE_PS_BOARD_FREE,no);
			Sy.s("전송할 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(
					rs.getString("B_NO"),
					rs.getString("B_TITLE"),
					rs.getString("B_ID"),
					rs.getString("B_TEXT"),
					rs.getString("B_DATETIME")
					);
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}
	
	// 글 목록
	public ArrayList<Dto> list(String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*Board.LIST_AMOUNT;  // 시작 페이지 구하기
			String sql = String.format("SELECT * FROM %s LIMIT %s,%s"
					,Db.TABLE_PS_BOARD_FREE,startIndex,Board.LIST_AMOUNT);
			Sy.s("전송한 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_TEXT"),
						rs.getString("B_DATETIME")
						));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	// 목록 - 총 글 수 구하기
	public int getPostCount() {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("SELECT COUNT(*) FROM %s"
					,Db.TABLE_PS_BOARD_FREE);
			Sy.s("전송한 sql문:"+sql); // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 목록 - 총 페이지 수
	public int getTotalPageCount() {
		int totalPageCount = 0;
		int count = getPostCount();
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		} else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 목록 - 총 글수 구하기(검색)
	public int getSearchPostCount(String word) {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("SELECT COUNT(*) FROM %s WHERE B_TITLE LIKE '"
					+"%%%s%%",Db.TABLE_PS_BOARD_FREE,word);
			Sy.s("전송할 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("COUNT(*)");
		}catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 글 목록 - 검색
	public ArrayList<Dto> listSearch(String word, String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*Board.LIST_AMOUNT;
			
			String sql = String.format("SELECT * FROM %s WHERE B_TITLE LIKE '%%%s%%' LIMT %s,%s"
					,Db.TABLE_PS_BOARD_FREE,word,startIndex,Board.LIST_AMOUNT);
			Sy.s("전송할 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_TEXT"),
						rs.getString("B_DATETIME")
						));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	// 목록 - 총 페이지 수(검색)
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		int count = getPostCount();
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		} else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 수정
	public void edit(Dto d,String no) {
		super.connect();
		String sql = String.format("update %s set B_TITLE='%s',B_TEXT='%s' where B_NO=%s"
				,Db.TABLE_PS_BOARD_FREE, d.title,d.text,no);
		Sy.s("전송할 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
}
