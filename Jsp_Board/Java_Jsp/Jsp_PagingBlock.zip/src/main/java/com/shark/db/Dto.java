package com.shark.db;

public class Dto {
	public String no;
	public String title;
	public String id;
	public String text;
	public String datetime;
	
	public Dto(String title, String id, String text) {
		this.title = title;
		this.id = id;
		this.text = text;
	}
	
	public Dto(String no, String title, String id, String text, String datetime) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
	}
	
	public Dto(String title, String text) {
		this.title = title;
		this.text = text;
	}
	
	public Dto(String title, String id, String text, String datetime) {
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
	}
}
