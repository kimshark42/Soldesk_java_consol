package com.shark;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Test
 */
@WebServlet("/Test")
public class Test extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws
	ServletException, IOException{
		
		System.out.println("==== 두 겟");
		System.out.println("ID:"+req.getParameter("id"));
		System.out.println("Password"+req.getParameter("pw"));
		
		
		HttpSession session = req.getSession();
		PrintWriter out = resp.getWriter();
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		
		// 서블릿에 id, pw 값 지정
		if(id.equals("shark") && pw.equals("1234")) {
			
			// 세션에 id 저장
			session.setAttribute("shark",id);
			session.setAttribute("1234",pw);
			// 세션 타임아웃을 30초로 지정
			session.setMaxInactiveInterval(5);
			// out 객체 이용해서 index2.jsp 링크 추가하기
			resp.sendRedirect("index2.jsp");			
		} else {
			out.print("no");
		}
	}
}
