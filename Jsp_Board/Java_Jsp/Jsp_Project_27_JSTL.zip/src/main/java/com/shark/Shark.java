package com.shark;

public class Shark {
	
	public String name = "김상어";
}
