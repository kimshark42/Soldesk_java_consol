package com.shark.d;

public class Dto {
	
	// todo null 값은 넣어도 되는가?
	public String no = null;
	public String title = null;
	public String id = null;
	public String datetime = null;
	public String hit = null;
	public String text = null;
	public String replyCount = null;
	public String replyOri = null;
	
	public Dto(String title, String id, String text) {
		this.title = title;
		this.id = id;
		this.text = text;
	}
	
	// alt + shift + s 코드 자동 삽입으로 넣어지는 함수
	public Dto(String no, String title, String id, String datetime, String hit, String text,
			String replyCount, String replyOri) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
		this.text = text;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}
	public Dto(String title, String text) {
		this.title = title;
		this.text = text;
	}
}
