package com.shark.d;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Da {

	Connection con = null;
	Statement st = null;

	// 삭제
	public void delet(String no) {
		super.connect(); // connect(); 로 해도 됨
//		connect();

		String sql = String.format("delete from %s where d_no=%s", Db.TABLE_PS_BOARD_FREE, no); // -> 자유 게시판 db 에 보내겠다
		System.out.println("전송할 sql문:" + sql); // 로그
		super.update(sql);
		super.close();
	}

	// 쓰기
	public void write(Dto d) {
		super.connect();

		String sql = String.format("INSERT INTO %s(d_title, d_id, d_text)" + "VALUES ('%s','%s','%s')",
				Db.TABLE_PS_BOARD_FREE, d.title, d.id, d.text);
		System.out.println("전송한 sql문:" + sql); // 로그
		super.update(sql);
		super.close();
	}

	// 읽기
	public Dto read(String no) {
		Dto post = null;
		super.connect();
		try {

			String sql = String.format("select * from %s where d_no=%s", Db.TABLE_PS_BOARD_FREE, no);
			System.out.println("전송된 sql문:" + sql); // log 찍기
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(rs.getString("D_NO"), rs.getString("D_TITLE"), rs.getString("D_ID"),
					rs.getString("D_DATETIME"), rs.getString("D_HIT"), rs.getString("D_TEXT"),
					rs.getString("D_REPLY_COUNT"), rs.getString("D_REPLY_ORI"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}

	// 목록
	public ArrayList<Dto> list() {
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {

			String sql = String.format("select *from %s", Db.TABLE_PS_BOARD_FREE);
			System.out.println("전송한 sql문:" + sql);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Dto(rs.getString("d_no"), rs.getString("d_title"), rs.getString("d_id"),
						rs.getString("d_datetime"), rs.getString("d_hit"), rs.getString("d_text"),
						rs.getString("d_reply_count"), rs.getString("d_reply_ori")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}

	// 수정
	public void edit(Dto d, String no) {
		super.connect();

		String sql = String.format("UPDATE %s SET d_title='%s'," + "d_text='%s'where d_no=%s", Db.TABLE_PS_BOARD_FREE,
				d.title, d.text, no);
		System.out.println("전송된 sql문:" + sql);
		update(sql);
		super.close();
	}
}
