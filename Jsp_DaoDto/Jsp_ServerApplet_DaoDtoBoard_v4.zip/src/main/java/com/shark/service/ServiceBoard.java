package com.shark.service;

import com.shark.board.BoardPagingBlock;
import com.shark.db.Dto;
import com.shark.db.dao.DaoBoard;

public class ServiceBoard {
	
	DaoBoard dao;
	
	public ServiceBoard() {
		dao = new DaoBoard();
	}
	
	public void delete(String category, String no) {
		dao.delete(category, no);
	}
	
	public void write(Dto d) {
		dao.write(d);
	}
	
	public Dto read(String category, String no) {
		return dao.read(category, no);
	}
	
	public BoardPagingBlock list(String category, String currentPage, String word) {
		if(currentPage == null) {
			currentPage = "1";
		}
		BoardPagingBlock blp = new BoardPagingBlock(dao, category, currentPage, word);
		return blp;
	}
	
	public void edit(Dto d,String no) {
		dao.edit(d, no);
	}
}
