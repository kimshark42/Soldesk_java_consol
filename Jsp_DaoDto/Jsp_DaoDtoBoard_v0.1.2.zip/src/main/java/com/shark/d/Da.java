package com.shark.d;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Da {
	Connection con = null;
	Statement st = null;
	
	void connect() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	void update(String sql) {
		try {
			st.executeUpdate(sql);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	void close() {
		try {
			st.close();
			con.close();
			// 이것도 고정, 이거 하면 실행 후 db와의 연결이 끊김
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
