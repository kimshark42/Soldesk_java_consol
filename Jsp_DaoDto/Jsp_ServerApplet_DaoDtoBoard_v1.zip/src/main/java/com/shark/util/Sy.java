package com.shark.util;

// 자주 쓰는 함수 ex) System.out.println(); 같은거 모아둔 java.class
// 함수를 사용할 class 안에 import com.shark.util.*; 이런식으로 넣어두면 됨
// Jsp 역시 <%@page %> 안에 class 에 넣은거랑 똑같이 넣으면 됨

public class Sy {

	// System.out.println();
	public static void s(String s) {
		System.out.print(s);
	}

	// sy 함수 - 오버로딩
	public static void sy(String s) {
		System.out.println(s);
	}
	
	// 그냥 엔터 하나 넣어주는 함수
	public static void sy() {
		System.out.println();
	}
}
