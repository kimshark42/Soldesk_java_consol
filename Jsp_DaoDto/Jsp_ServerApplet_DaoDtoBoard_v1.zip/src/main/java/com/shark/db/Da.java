package com.shark.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Da {
	
	Connection con = null;
	Statement st = null;
	
	// db 연결
	void connect() {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL,Db.DB_ID,Db.DB_PW);
			st = con.createStatement();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// sql 업데이트문 전송
	void update(String sql) {
		try {
			st.executeUpdate(sql);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	// db 연결 해제
	void close() {
		try {
			st.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
