package com.shark.db;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.shark.util.Sy;

public class Dao extends Da {
	
	// 삭제
	public void delete(String no) {
		super.connect();
		String sql = String.format("DELETE FROM %s WHERE B_NO=%s"
				,Db.TABLE_PS_BOARD,no);
		Sy.s("전송한 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
	
	// 쓰기
	public void write(Dto d) {
		super.connect();
		String sql = String.format("INSRT INTO %s (B_TITLE,B_ID,B_TEXT,B_DATETIME VALUES ("
				+ "'%s','%s','%s',now()",Db.TABLE_PS_BOARD,d.title,d.id,d.text);
		Sy.s("전송한 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
	
	// 글 읽기
	public Dto read(String no) {
		super.connect();
		Dto post = null;
		try {
			String sql = String.format("SELECT * FROM %s WHERE B_NO=%s"
					,Db.TABLE_PS_BOARD,no);
			Sy.s("전송한 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(
					rs.getString("B_NO"),
					rs.getString("B_TITLE"),
					rs.getString("B_ID"),
					rs.getString("B_TEXT"),
					rs.getString("B_DATETIME"),
					rs.getString("B_HIT"),
					rs.getString("B_REPLY_COUNT"),
					rs.getString("B_REPLY_ORI")
					);
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}
	
	// 글 목록
	public ArrayList<Dto> list(String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			
			// 시작 페이지 설정
			int startIndex = ((Integer.parseInt(page))-1)*Board.LIST_AMOUNT;
			
			String sql = String.format("SELECT * FROM %s LIMIT %s,%s"
					,Db.TABLE_PS_BOARD,startIndex,Board.LIST_AMOUNT);
			Sy.s("전송한 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_TEXT"),
						rs.getString("B_DATETIME"),
						rs.getString("B_HIT"),
						rs.getString("B_REPLY_COUNT"),
						rs.getString("B_REPLY_ORI")
						));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	// 총 글 수 구하기
	public int getPostCount() {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("SELECT CONUT(*) FROM %s"
					,Db.TABLE_PS_BOARD);
			Sy.s("전송된 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 총 페이지수 구하기
	public int getTotalPageCount() {
		int totalPageCount = 0;
		int count = getPostCount();  // 총 글 수 구하기 할때 썼던거 재활용
		
		if(count % Board.LIST_AMOUNT == 0) {  // 1.case 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		} else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 글 목록 - 검색모드
	public ArrayList<Dto> listSearch(String word, String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			
			// 시작 페이지 설정
			int startIndex = ((Integer.parseInt(page))-1)*Board.LIST_AMOUNT;
			
			String sql = String.format("SELECT * FROM %s WHERE B_TITLE '%%%s%%' LIMIT %s,%s"
					,Db.TABLE_PS_BOARD,word,startIndex,Board.LIST_AMOUNT);
			Sy.s("전송한 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_TEXT"),
						rs.getString("B_DATETIME"),
						rs.getString("B_HIT"),
						rs.getString("B_REPLY_COUNT"),
						rs.getString("B_REPLY_ORI")
						));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	// 총 글 수 구하기 - 검색모드
	public int getSearchPostCount(String word) {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("SELECT CONUT(*) FROM %s WHERE B_TITLE LIKE '%%%s%%'"
					,Db.TABLE_PS_BOARD,word);
			Sy.s("전송된 sql문:"+sql);  // 로그
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 총 페이지 수 구하기 - 검색
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		int count = getSearchPostCount(word);  // 총 글 수 구하기 할때 썼던거 재활용
		
		if(count % Board.LIST_AMOUNT == 0) {  // 1.case 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / Board.LIST_AMOUNT;
		} else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	// 수정
	public void edit(Dto d, String no) {
		super.connect();
		
		// 작은 따옴표 차단
		if (d.title.contains("'") || d.text.contains("'")) {
	        Sy.s("🚫 작은따옴표가 포함되어 수정이 차단되었습니다.");
	        super.close();
	        return;  // 더 이상 진행하지 않고 종료
	    }
		String sql = String.format("UPDATE %s SET B_TITLE='%s',B_TEXT='%s' WHERE B_NO=%s"
				,Db.TABLE_PS_BOARD,d.title,d.text,no);
		Sy.s("전송한 sql문:"+sql);  // 로그
		super.update(sql);
		super.close();
	}
}
