package com.shark.db;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ServletEdit")
public class ServletEdit extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Dto dto = new Dto(
				request.getParameter("title"),
				request.getParameter("text")
				);
		Dao dao = new Dao();
		dao.edit(dto, request.getParameter("no"));
		
		// todo jsp 내부에서 팝업 클릭시 이동 하는거 만들기
		// out 객체 출력으로 얻어와서 출력
		PrintWriter out = response.getWriter();
		out.println("<script>alert('cat')</script>");
		
		response.sendRedirect("list.jsp");
		
		
	}

}
