package com.shark.db;

public class Db {
	
	public static String DB_JDBC_DRIVER_PACKAGE_PATH = "com.mysql.cj.jdbc.Driver";  //mysql
	
	private static String DB_NAME = "my_cat";
	private static String DB_URL_MYSQL = "jdbc:mysql://localhost:3306/"+DB_NAME;
	
	public static String DB_URL = DB_URL_MYSQL;  // DB가 바뀌면 여길 바꿀것
	public static String DB_ID = "root";
	public static String DB_PW = "root";
	
	/* table */
	public static String TABLE_PS_BOARD = "board";  // 자유 게시판
	
}
