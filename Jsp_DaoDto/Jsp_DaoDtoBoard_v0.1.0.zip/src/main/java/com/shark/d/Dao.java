package com.shark.d;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao {
	
	Connection con = null;
	Statement st = null;
	
	// 삭제
	public void delet(String no) {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
			
			String sql = String.format("delete from %s where d_no=%s",
					Db.TABLE_PS_BOARD_FREE,no);  // -> 자유 게시판 db 에 보내겠다
			System.out.println("전송할 sql문:"+sql);  // 로그
			st.executeUpdate(sql);  // my sql에 전송
			st.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	// 쓰기
	public void write(Dto d) {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
			
			String sql = String.format("INSERT INTO %s(d_title, d_id, d_text)"
					+"VALUES ('%s','%s','%s')",Db.TABLE_PS_BOARD_FREE, d.title, d.id, d.text);
			System.out.println("전송한 sql문:"+sql);  // 로그
			st.executeQuery(sql);
			st.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	// 읽기
	public Dto read(String no) {
		Dto post = null;
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
			
			String sql = String.format("select * from %s where d_no=%s",
					Db.TABLE_PS_BOARD_FREE,no);
			System.out.println("전송된 sql문:"+sql);  // log 찍기
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(
					rs.getString("D_NO"),
					rs.getString("D_TITLE"),
					rs.getString("D_ID"),
					rs.getString("D_DATETIME"),
					rs.getString("D_HIT"),
					rs.getString("D_TEXT"),
					rs.getString("D_REPLY_COUNT"),
					rs.getString("D_REPLY_ORI")
					);
			st.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		// todo 이거 왜 오류나는지 물어보기, 왠지는 모르겠는데 해결함 타입 어쩌고였는데 그거 물어보기
		return post;
	}
	// 목록
	public ArrayList<Dto>list(){
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
			
			String sql = String.format("select *from %s",Db.TABLE_PS_BOARD_FREE);
			System.out.println("전송한 sql문:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("d_no"),
						rs.getString("d_title"),
						rs.getString("d_id"),
						rs.getString("d_datetime"),
						rs.getString("d_hit"),
						rs.getString("d_text"),
						rs.getString("d_reply_count"),
						rs.getString("d_reply_ori")
						));
			}
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;
	}
	// 수정
	public void edit(Dto d, String no) {
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);
			st = con.createStatement();
			// 위 세줄은 고정, 사유 -> mysql 연결
			
			String sql = String.format("UPDATE %s SET d_title='%s',"
					+"d_text='%s'where d_no=%s",Db.TABLE_PS_BOARD_FREE,d.title, d.text, no);
			System.out.println("전송된 sql문:"+sql);
			st.executeUpdate(sql);
			st.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
