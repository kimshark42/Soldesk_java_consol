package com.shark.db;

public class Dto {
	
	public String no;
	public String title;
	public String id;
	public String datetime;
	public String text;
	public String hit;
	public String replyCount;
	public String replyOri;
	
	public Dto(String no, String title,String id, String text, String datetime, String hit
			, String replyCount, String replyOri) {
		this.no = no;
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
		this.hit = hit;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}
	
	public Dto(String title, String text) {
		this.title = title;
		this.text = text;
	}
	
	public Dto(String title,String id, String text) {
		this.title = title;
		this.id = id;
		this.text = text;
	}
	
	public Dto(String title,String id, String text, String datetime) {
		this.title = title;
		this.id = id;
		this.text = text;
		this.datetime = datetime;
	}
}
