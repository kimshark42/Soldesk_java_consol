package com.shark.db.board;

public class Board {
	
	// 페이징 블럭 설정
    final public static int LIST_AMOUNT = 5;  // 하나의 리스트에 보일 글 수
	final public static int PAGE_LINK_AMOUNT = 3;  // 페이지 링크 한 블럭에 보일 페이지 갯수
		
	/* table */
	public static String TABLE_PS_BOARD = "board";  // 자유 게시판
}
