package com.shark.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shark.db.Dto;
import com.shark.jspdaodtoboard.BoardPagingBlock;
import com.shark.service.ServiceBoard;
import com.shark.util.Sy;

// todo 강사님께 이 servlet 클래스 설명 부탁하기

@WebServlet("/board/")
public class ControllerBoard extends HttpServlet {
	String nextPage;
	ServiceBoard service;
	
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse reponse) throws ServletException, IOException {
		String action = request.getPathInfo();
		Sy.s("action:"+action);  // 로그
		if(action!=null) {
			switch(action) {
			case "/del":
				nextPage = "/board/list";  // 컨트롤러 리스트를 타게 수정
				service.delete(request.getParameter("no"));
				break;
			case "/write":
				nextPage = "/board/list";   // 컨트롤러 리스트를 타게 수정
				Dto dto = new Dto(
						request.getParameter("title"),
						request.getParameter("id"),
						request.getParameter("text")
						);
				service.write(dto);  // 서비스 쓰기 가능
				break;
			case "/edit":
				Sy.s("수정-insert");  // 로그
				nextPage = "/edit.jsp";
				request.setAttribute("post", service.read(request.getParameter("no")));  // 서비스 수정 가능
				break;
			case "/editBoard":
				Sy.s("수정-board");
				nextPage = "/board/list";  // 컨트롤러 리스트를 타게 수정
				service.edit(new Dto(
						request.getParameter("title"),
						request.getParameter("text"))
						,request.getParameter("no"));  // 서비스 수정 가능
				break;
			case "/read":
				nextPage = "/read.jsp";
				Dto d = service.read(request.getParameter("no"));  // 서비스 읽기 가능
				request.setAttribute("post", d);
				break;
			case "/list":
				nextPage = "/list.jsp";
				// 리스트 관련 각종 처리를 다 한 BoardPagingBlock 객체 넘기기
				BoardPagingBlock blp = service.list(request.getParameter("page")
						,request.getParameter("word"));  // 서비스 리스트 기능
				request.setAttribute("blp", blp);
				break;
			}
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, reponse);
		}
	}
}
