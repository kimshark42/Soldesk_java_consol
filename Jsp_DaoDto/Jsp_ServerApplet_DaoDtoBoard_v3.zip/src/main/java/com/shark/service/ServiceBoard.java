package com.shark.service;

import com.shark.db.Dto;
import com.shark.db.dao.DaoBoard;
import com.shark.jspdaodtoboard.BoardPagingBlock;

/* 서비스 */
public class ServiceBoard {
	
	DaoBoard dao;
	
	public ServiceBoard() {
		dao = new DaoBoard();
	}
	
	public void delete(String no) {
		dao.delete(no);
	}
	
	public void write(Dto d) {
		dao.write(d);
	}
	
	public Dto read(String no) {
		return dao.read(no);
	}
	
	public BoardPagingBlock list(String currentPage, String word) {
		if(currentPage == null) {
			currentPage = "1";
		}
		BoardPagingBlock blp = new BoardPagingBlock(dao,currentPage,word);
		return blp;
	}
	
	public void edit(Dto d,String no) {
		dao.edit(d, no);
	}
}
