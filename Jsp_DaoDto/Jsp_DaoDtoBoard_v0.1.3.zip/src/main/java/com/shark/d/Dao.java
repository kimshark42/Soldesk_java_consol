package com.shark.d;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Da {

	Connection con = null;
	Statement st = null;

	// 삭제
	public void delet(String no) {
		super.connect(); // connect(); 로 해도 됨
//		connect();

		String sql = String.format("delete from %s where d_no=%s", Db.TABLE_PS_BOARD_FREE, no); // -> 자유 게시판 db 에 보내겠다
		System.out.println("전송할 sql문:" + sql); // 로그
		super.update(sql);
		super.close();
	}

	// 쓰기
	public void write(Dto d) {
		super.connect();

		String sql = String.format("INSERT INTO %s(d_title, d_id, d_text)" + "VALUES ('%s','%s','%s')",
				Db.TABLE_PS_BOARD_FREE, d.title, d.id, d.text);
		System.out.println("전송한 sql문:" + sql); // 로그
		super.update(sql);
		super.close();
	}

	// 읽기
	public Dto read(String no) {
		Dto post = null;
		super.connect();
		try {

			String sql = String.format("select * from %s where d_no=%s", Db.TABLE_PS_BOARD_FREE, no);
			System.out.println("전송된 sql문:" + sql); // log 찍기
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Dto(rs.getString("D_NO"), rs.getString("D_TITLE"), rs.getString("D_ID"),
					rs.getString("D_DATETIME"), rs.getString("D_HIT"), rs.getString("D_TEXT"),
					rs.getString("D_REPLY_COUNT"), rs.getString("D_REPLY_ORI"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}
	
	// 목록
		public ArrayList<Dto> list() {
			super.connect();
			ArrayList<Dto> posts = new ArrayList<>();
			try {

				String sql = String.format("select *from %s", Db.TABLE_PS_BOARD_FREE);
				System.out.println("전송한 sql문:" + sql);
				ResultSet rs = st.executeQuery(sql);
				while (rs.next()) {
					posts.add(new Dto(rs.getString("d_no"), rs.getString("d_title"), rs.getString("d_id"),
							rs.getString("d_datetime"), rs.getString("d_hit"), rs.getString("d_text"),
							rs.getString("d_reply_count"), rs.getString("d_reply_ori")));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			super.close();
			return posts;
		}
		
		// 목록*오버로딩
		public ArrayList<Dto> list(String page) {
			super.connect();
			ArrayList<Dto> posts = new ArrayList<>();
			try {

				String sql = String.format("select *from %s", Db.TABLE_PS_BOARD_FREE);
				System.out.println("전송한 sql문:" + sql);
				ResultSet rs = st.executeQuery(sql);
				while (rs.next()) {
					posts.add(new Dto(rs.getString("d_no"), rs.getString("d_title"), rs.getString("d_id"),
							rs.getString("d_datetime"), rs.getString("d_hit"), rs.getString("d_text"),
							rs.getString("d_reply_count"), rs.getString("d_reply_ori")));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			super.close();
			return posts;
		}
	
	// 글 갯수 카운팅
	public int getPostCount() {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("select count(*) from %s"
					,Db.TABLE_PS_BOARD_FREE);
			System.out.println("전송한 sql문:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 총 글 수 구하기
	public int getSearchPostCount(String word) {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("select count(*) from %s where d_title like '%%%s%%'"
					,Db.TABLE_PS_BOARD_FREE,word);
			System.out.println("전송된 sql문:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return count;
	}
	
	// 글 목록<검색>
	public ArrayList<Dto> listSearch(String word,String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*3;
			
			String sql = String.format(
					"select * from %s where d_title like '%%%s%%' limit %s,3"
					,Db.TABLE_PS_BOARD_FREE,word,startIndex);
			System.out.println("전송할 sql문:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("d_no"),
						rs.getString("d_title"),						
						rs.getString("d_id"),						
						rs.getString("d_datetime"),						
						rs.getString("d_hit"),						
						rs.getString("d_text"),						
						rs.getString("d_reply_count"),						
						rs.getString("d_reply_ori")						
						));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	// 총 페이지 수 구하기
	public int getTotalPageCount() {
		int totalPageCount = 0;
		int count = getPostCount();  //위에서 만들어 놨던거 재활용
		
		if(count % 3 == 0) {  // case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / 3;
		} else {  // case2. 짜투리 페이지가 필요한경우
			totalPageCount = count / 3 + 1;
		}
		return totalPageCount;
	}
	
	// 총 페이지 수 구하기 <검색>
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		int count = getSearchPostCount(word);
		
		if(count % 3 == 0) {  // case1. 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / 3;
		} else {  // case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
			totalPageCount = count / 3 + 1;
		}
		return totalPageCount;
	}

	// 수정
	public void edit(Dto d, String no) {
		super.connect();

		String sql = String.format("UPDATE %s SET d_title='%s'," + "d_text='%s'where d_no=%s", Db.TABLE_PS_BOARD_FREE,
				d.title, d.text, no);
		System.out.println("전송된 sql문:" + sql);
		update(sql);
		super.close();
	}
}
