package com.shark.d;

public class Db {
	
	static final public String DB_JDBC_DRIVER_PACKAGE_PATH = "com.mysql.cj.jdbc.Driver";  // mysql
	
	
	static final private String DB_NAME = "my_cat";
	static final private String DB_URL_MYSQL = "jdbc:mysql://localhost:3306/"+DB_NAME;
	
	static final public String DB_URL = DB_URL_MYSQL;	
	static final public String DB_ID = "root";	
	static final public String DB_PW = "root";
	
    /* table */
	// 게시판
	final public static String TABLE_PS_BOARD_FREE = "DaoDtoBoard";  // 자유 게시판
}
