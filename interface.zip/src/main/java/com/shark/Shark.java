package com.shark;

public class Shark extends fish {
	
	public void run() {
		System.out.println("따이하게 헤엄침");
	}

}
