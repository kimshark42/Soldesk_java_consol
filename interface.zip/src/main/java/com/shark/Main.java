package com.shark;

public class Main {

	public static void main(String[] args) {
		
		Shark shark = new Shark();
		
		shark.run();
	}

}
