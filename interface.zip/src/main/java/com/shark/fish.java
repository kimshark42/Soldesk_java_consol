package com.shark;

// 상속 DLC
// 추상클래스
public abstract class fish {
	
    // public interface Animal -> 이건 더이상 class 가 아님
	// 따라서 이건 사실상 추상함수만 쓸수 있음
	// 대신 이렇게되면 추상함수는 앞에 public을 붙여야됨
	
	// 자식들에게는 extends 대신 implements 라고 써야됨
	// 원래는 구현했다 라고 표현하지만 이해하기 편하게 상속했다라고 지칭
	// 그리고 이러면 자식들은 부모의 추상함수를 반드시 써야함
	
	 // 추상함수
	// 이건 여러게를 둘수도 있음, 일반함수 추가도 가능함
	 abstract void run();
	 
//	 void run() {
//		 System.out.println("헤엄치다");
//	 }
}
