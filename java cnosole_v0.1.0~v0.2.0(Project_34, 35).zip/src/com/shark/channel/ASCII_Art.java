package com.shark.channel;

public class ASCII_Art extends Channel {
	public ASCII_Art(String xx,int yy) {
		super(xx, yy);
	}
}
