package com.shark.channel;

public class Announcement extends Channel {	
	public Announcement(String xx, int yy) {
		super(xx, yy);
	}
}
