package com.shark.mapper;

import com.shark.dto.TestDto;

public interface TestMapper {
	public TestDto getData1();
	public TestDto getData2();
	public TestDto getData3();
	public TestDto getData4();
	
	/* 🦈1+2 개발🦈 문제 1 */
	public void updateVisitantCount();
	
	/* 🦈1+2 개발🦈 문제 2 */
	public void insertDoodle();
	
	/* 🦈1+2 개발🦈 문제 3 */
	public void delTest();
}
