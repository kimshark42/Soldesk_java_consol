package com.shark.service;

public interface TestService {
	public String getOne();
	public String getTwo();
	
	/* 🦈1+2 개발🦈 문제 1 */
	public void updateVisitantCount();
	
	/* 🦈1+2🦈 개발 문제 2*/
	public void insertDoodle();
	
	/* 🦈1+2🦈 개발 문제 3*/
	public void delTest();
}
