package com.shark.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shark.dto.TestDto;
import com.shark.mapper.TestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
// 지난번에 했던 상속 비슷한거(interface)
// interface의 특이점으로 반드시 상속받은 함수를 재정의 해야만 함
public class TestServiceImpl implements TestService {
	
	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;
	
	// tvo -> 예전에 Dao Dto 했던것처럼 tvo 가 DaoDto 역할을 한다고 보면 됨
	@Override
	public String getOne() {
		log.info("test==========");
		TestDto tvo = mapper.getData1();
		String one = tvo.getStr_data();
		return one;
	}
	
	@Override
	public String getTwo() {
		log.info("test==========");
		TestDto tvo = mapper.getData2();
		String two = tvo.getStr_data();
		return two;
	}
	
	/* 🦈1+2 개발🦈 문제 1 */
	@Override
	public void updateVisitantCount() {
		mapper.updateVisitantCount();
	}
	
	/* 🦈1+2 개발🦈 문제 2 */
	@Override
	public void insertDoodle() {
		mapper.insertDoodle();
	}
	
	/* 🦈1+2 개발🦈 문제 3 */
	@Override
	public void delTest() {
		mapper.delTest();
	}
}
