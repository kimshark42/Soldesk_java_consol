package com.shark.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shark.dto.GuestDto;
import com.shark.mapper.GuestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class GuestServiceImpl implements GuestService {
	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;
	
	// list
	@Override
	public ArrayList<GuestDto> getList() {
		log.info("비즈니스 계층 ========== list");
		return mapper.getList();
	}
	
	// read
	@Override
	public GuestDto read(long bno) {
		log.info("비즈니스 계층 ========== read");
		return mapper.read(bno);
	}
	
	// delete
	@Override
	public void del(long bno) {
		log.info("비즈니스 계층 ========== delete");
		mapper.del(bno);
	}
	
	// write
	@Override
	public void write(GuestDto dto) {
		log.info("비즈니스 계층 ========== write");
		mapper.write(dto);
	}
	
	// edit
	@Override
	public void edit(GuestDto dto) {
		log.info("비즈니스 계층 ========== edit");
		mapper.edit(dto);
	}
}
