package com.shark.service;

import java.util.ArrayList;

import com.shark.dto.GuestDto;

public interface GuestService {
	
	// list
	public ArrayList<GuestDto> getList();
	
	// read
	public GuestDto read(long bno);
	
	// delete
	public void del(long bno);
	
	// write
	public void write(GuestDto dto);
	
	// edit
	public void edit(GuestDto dto);
}
