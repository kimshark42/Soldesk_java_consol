package com.shark.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shark.dto.GuestDto;
import com.shark.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j

// 프로젝트 루트 경로 이하 /guest 상위 폴더로 진입시 여기로 진입 하게 됨.
@RequestMapping("/guest/*")

// 필드 값을 매개변수로 하는 생성자를 스프링이 알아서 만들어 줌
// 그리고 그런 형태의 생성자를 추가하면 스프링이 알아서 객체관리 해줌(@Auto.. 처럼)
@AllArgsConstructor

@Controller
public class GuestController {
	
// 위에 @AllArgsConstructor 를 쓰면 lombok 라이브러리가 아래 코드를 자동으로 삽입해줌 (F3 또는 Ctrl + 어노테이션 클릭)
//	public GuestController(GuestService service){
//		this.service = service;
//	}
	
	private GuestService service;
	
	// list
	// 프로젝트 루트 경로 이하 /guest/getList url 진입시 여기로 진입 하게 됨.
	@GetMapping("/getList")
	// 매개변수에 Model m 식으로 작성하게 되면, 스프링이 알아서 모델 객체를 만들어서 넘겨줌.
	public void getList(Model model) {
		// 로그
		log.info("컨트롤러, 글 목록 연결");
		// 위 /getList 와 동일한<(/guest)상위경로 포함> jsp파일을 염, 즉 PJ 루트 /guest/getList.jsp 파일을 염
		model.addAttribute("list",service.getList());
	}
	// 그리고 이 파일은
	// PJ/src/main/webapp/WEB-INF/views/guest/getList.jsp
	// 에 만들어 놓으면 됨
	
	// read
	// 프로젝트 루트 경로 이하 /guest/read url 진입시 여기로 진입 하게 됨.
	@GetMapping({"/read","/edit"})
	public void read(@RequestParam("bno") Long bno, Model model) {
		// 로그
		log.info("컨트롤러, read ======== 글 번호 ========" + bno);
		// 위 /getList 와 동일한<(/guest)상위경로 포함> jsp파일을 염, 즉 PJ 루트 /guest/getList.jsp 파일을 염
		model.addAttribute("read",service.read(bno));
	}
	
	// delete
	// 프로젝트 루트 경로 이하 /guest/del url 진입시 여기로 진입 하게 됨.
	@GetMapping("/del")
	public String del(@RequestParam("bno") Long bno) {
		// 로그
		log.info("컨트롤러, delete ======== 글 번호 ========" + bno);
		service.del(bno);
		// 글 삭제 후 list 로 강제전송
		return "redirect:/guest/getList";
	}
	
	// write
	// 프로젝트 루트 경로 이하 /guest/write (Post 방식으로 오면 여기로 옴) **여태 오던 GET 방식 아님!!! 주의**
	@PostMapping("/write")
	// 폼 태그의 textarea 에 btext 변수로 데이터가 넘아왔는데
	// 매개변수에 (GuestVO gvo) 이런 클래스를 선언해 놓게 되면
	// 해당 객체의 멤버변수에 스프링이 알아서 채워줌
	public String write(GuestDto dto) {
		// 로그
		log.info("컨트롤러, write ======== 글 ========" + dto);
		service.write(dto);
		// 글 전솧 후 list 로 강제전송
		return "redirect:/guest/getList";
	}
	// get 방식으로 넘어왔을 경우 여기로 이동, write 중복 아닌가요? -> 글쓰기 화면을 위한 url 매핑임
	@GetMapping("/write")
	public void write() {
		log.info("컨트롤러, write ======== 글 ======= get 방식으로 넘어옴");
	}
	
	// edit
	// 프로젝트 루트 경로 이하 /guest/edit (Post 방식으로 오면 여기로 옴) **여태 오던 GET 방식 아님!!! 주의**
	@PostMapping("/edit")
	// 폼 태그의 textarea 에 btext 변수로 데이터가 넘아왔는데
	// 매개변수에 (GuestVO gvo) 이런 클래스를 선언해 놓게 되면
	// 해당 객체의 멤버변수에 스프링이 알아서 채워줌
	public String edit(GuestDto dto) {
		// 로그
		log.info("컨트롤러, edit ======== 글 ========" + dto);
		service.edit(dto);
		// 글 전솧 후 list 로 강제전송
		return "redirect:/guest/getList";
	}
	
	// 위의 read 에서 같이 처리해도 되지만 햇갈릴경우 그냥 따로 써도 됨
	// get 방식으로 넘어왔을 경우 여기로 이동, edit 중복 아닌가요? -> 글쓰기 화면을 위한 url 매핑임
//	@GetMapping("/edit")
//	public void edit(@RequestParam("bno") Long bno, Model model) {
//		log.info("컨트롤러, edit ======== 글 ======= get 방식으로 넘어옴");
//		model.addAttribute("read",service.read(bno));
//	}

}
