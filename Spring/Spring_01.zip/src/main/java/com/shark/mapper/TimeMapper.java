package com.shark.mapper;

import org.apache.ibatis.annotations.Select;

// interface -> 추상함수만 있는 클래스
// 2025.06.04 기준 대충 상속 비슷한것으로 보면 됨
public interface TimeMapper {
	// @Select("SELECT sysdate From dual")
	@Select("SELECT now() From dual")
	public String getTime();
	
	public String getTime2();
}
