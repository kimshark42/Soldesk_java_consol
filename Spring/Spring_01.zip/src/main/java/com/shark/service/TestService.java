package com.shark.service;

public interface TestService {
	public String getOne();
	public String getTwo();
}
