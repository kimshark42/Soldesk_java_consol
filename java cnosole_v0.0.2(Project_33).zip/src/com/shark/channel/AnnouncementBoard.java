package com.shark.channel;

public class AnnouncementBoard extends Channel {
	public AnnouncementBoard(String xx, int yy) {
		super(xx, yy);
	}
}
